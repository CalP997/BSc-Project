﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
/*
 * base character controller built upon and used from previously used code for navigating the hub ship
 * this is the base code and will be edited for both planets to add in additions such as picking up parts.
 */
public class BasePlayerController : MonoBehaviour {

    public float playerspeed;
    public float height;
    private CollisionFlags collisions;
    private CharacterController m_CharacterController;
    public GameObject player;
    public GameObject menu;
    public GameObject menuscreen;
    public GameObject helpscreen;
    public GameObject mCam;

    // Use this for initialization
    public Vector3 jump;
    public float jumpForce = 2.0f;

    public bool isGrounded;
    Rigidbody rb;

    // Use this for initialization
    void Start()
    {
        m_CharacterController = GetComponent<CharacterController>();
        Scene currentScene = SceneManager.GetActiveScene();

        rb = GetComponent<Rigidbody>();
        //player jump height
        jump = new Vector3(0.0f, 5.0f, 0.0f);

        //show/hide pointer dependant on the screen (show on menus/loading screens, hide on game/level screens)
        string sceneName = currentScene.name;
        if (sceneName == "Menu" || sceneName == "Extras" || sceneName == "Loading1" || sceneName == "Loading2")
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }

    // Update is called once per frame
    void Update()
    {
        //Code used to move the player
        float vertical = Input.GetAxis("Vertical") * playerspeed;//move on z axis (forward/back) at set speed
        float horizontal = Input.GetAxis("Horizontal") * playerspeed;//move on x axis (left/right) at set speed
        vertical *= Time.deltaTime;//keep the movement rate the same
        horizontal *= Time.deltaTime;
        transform.Translate(horizontal, 0, vertical);
        //escape/shop mouse code
        if (Input.GetKeyDown("escape"))
        {
            Cursor.lockState = CursorLockMode.None;//if escape is pressed show cursor
        }
        //added jump code to make terrain exploration easier
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {

            rb.AddForce(jump * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }
        //sprint code to increase the player speed to 10, making the player faster
        if (Input.GetKey(KeyCode.RightShift))
        {
            playerspeed = 12;
        }
        else
        {
            playerspeed = 4;
        }

        //show menu
        if (Input.GetKeyDown("m"))
        {
            Cursor.lockState = CursorLockMode.None;
            menu.SetActive(true);
            mCam.SetActive(true);
            player.SetActive(false);
        }
    }
    //pad colision
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("IcePad"))//when the box collider is crossed
        {
            Debug.Log("IcePlanet");
            SceneManager.LoadScene(4);//load loading scene
        }
        if (other.gameObject.CompareTag("LavaPad"))//when the box collider is crossed
        {
            Debug.Log("LavaPlanet");
            SceneManager.LoadScene(5);//load loading scene
        }
    }
    //collision code from fps controller was need to stop player falling through hub ship floor, detects for collisons
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody body = hit.collider.attachedRigidbody;
        //dont move the rigidbody if the character is on top of it
        if (collisions == CollisionFlags.Below)
        {
            return;
        }

        if (body == null || body.isKinematic)
        {
            return;
        }
        //body.AddForceAtPosition(m_CharacterController.velocity * 0.1f, hit.point, ForceMode.Impulse);
    }
    //check if the player is on the ground
    void OnCollisionStay()
    {
        isGrounded = true;
    }
    void OnCollisionExit()
    {
        isGrounded = false;
    }

    //menu buttons code
    public void HelpMenu()
    {
        Cursor.lockState = CursorLockMode.None;
        menuscreen.SetActive(false);
        helpscreen.SetActive(true);
    }

    public void ReturnToMenu()
    {
        Cursor.lockState = CursorLockMode.None;
        helpscreen.SetActive(false);
        menuscreen.SetActive(true);
    }

    public void CloseMenu()
    {
        Cursor.lockState = CursorLockMode.Locked;
        menu.SetActive(false);
        mCam.SetActive(false);
        player.SetActive(true);
    }
    public void QuitGame()
    {
        SceneManager.LoadScene(0); //Return to menu
    }
}
