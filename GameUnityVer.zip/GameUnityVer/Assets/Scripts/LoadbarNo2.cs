﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadbarNo2 : MonoBehaviour {

    //create a load bar that loads the new level without closing the currently open level automatically
    public GameObject LoadingScreen;
    public GameObject Lava;
    public Slider slider;
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();

        string sceneName = currentScene.name;
        if (sceneName == "Menu" || sceneName == "Extras" || sceneName == "Loading1" || sceneName == "Loading2")
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }

    public void LoadLava(int sceneIndex)
    {
        Cursor.visible = true;
        StartCoroutine(LoadAsync(sceneIndex));
    }
    IEnumerator LoadAsync(int sceneIndex)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);

        LoadingScreen.SetActive(true);
        Lava.SetActive(false);

        while (operation.isDone == false)//while level not loaded
        {
            float progress = Mathf.Clamp01(operation.progress / .9f);

            slider.value = progress;

            Debug.Log(operation.progress);// show prog in debug menu for testing
            yield return null;//wait 1 frame
        }
    }
}
