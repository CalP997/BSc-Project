﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Menu : MonoBehaviour {

    public GameObject MainMenu;
    public GameObject OptionsScreen;
    public GameObject ExtrasScreen;
    public GameObject HelpScreen;
    public GameObject DetailsScreen;

    // Menu script to link buttons to scenes and close the game when it has been built
    // Use this for initialization
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();

        string sceneName = currentScene.name;
        if (sceneName == "Menu" || sceneName == "Extras" || sceneName == "Loading1" || sceneName == "Loading2")
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }

    public void PlayGame()
    {
        SceneManager.LoadScene(2); //play new game
    }

    //options
    public void Options()
    {
        MainMenu.SetActive(false);
        OptionsScreen.SetActive(true);
    }
    public void OptionsRet()
    {
        MainMenu.SetActive(true);
        OptionsScreen.SetActive(false);
    }

    //extras
    public void Extras()
    {
        MainMenu.SetActive(false);
        ExtrasScreen.SetActive(true);
    }
    public void ExtrasRet()
    {
        MainMenu.SetActive(true);
        ExtrasScreen.SetActive(false);
    }

    //help
    public void Help()
    {
        OptionsScreen.SetActive(false);
        HelpScreen.SetActive(true);
    }
    public void HelpRet()
    {
        OptionsScreen.SetActive(true);
        HelpScreen.SetActive(false);
    }

    //details
    public void Details()
    {
        ExtrasScreen.SetActive(false);
        DetailsScreen.SetActive(true);
    }
    public void DetailsRet()
    {
        ExtrasScreen.SetActive(true);
        DetailsScreen.SetActive(false);
    }

    //quit
    public void QuitGame()
    {
        Debug.Log("QUIT");//quit game
        Application.Quit();//will close the application once the game has been built
    }
}
