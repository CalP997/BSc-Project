﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour {
    Vector2 look;//keep track of camera movement
    Vector2 smooth;//smooth mouse movement
    public float mouseSensitivity = 5f;//sensitivity of mouse
    public float smoothing = 2f;//smoothing of the mouse movement

    GameObject Player;//reference to the player game object

    void Start()
    {
        //establish link between character and camera
        Player = this.transform.parent.gameObject;//code to say that the playerGO is the parent of the camera
    }

    void Update()
    {
        var mouseMovement = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));
        mouseMovement = Vector2.Scale(mouseMovement, new Vector2(mouseSensitivity * smoothing, mouseSensitivity * smoothing));
        smooth.x = Mathf.Lerp(smooth.x, mouseMovement.x, 1f / smoothing);//move camera smoothly in x axis
        smooth.y = Mathf.Lerp(smooth.y, mouseMovement.y, 1f / smoothing);//move camera smoothly in y axis
        //lock camera rotation on y axis
        look.y = Mathf.Clamp(look.y, -90f, 90f);

        look += smooth;

       

        transform.localRotation = Quaternion.AngleAxis(-look.y, Vector3.right);//rotate the camera on up and down the z axis
        //will move the whole character rather than just the camera, allowing the character to turn around
        Player.transform.localRotation = Quaternion.AngleAxis(look.x, Player.transform.up);
    }
}
