﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PartCode : MonoBehaviour
{
    
    int partFound = 0;//create int for finding part
    public GameObject Light1;//red light
    public GameObject Light2;//green light
    public GameObject Part;//part

    private void OnTriggerEnter(Collider other)
    {
        if (partFound != 1 && other.gameObject.CompareTag("TpPad"))//when the box collider is crossed and the part is found
        {
            Debug.Log("No part");
        }
        else if (partFound == 1 && other.gameObject.CompareTag("TpPad"))
        {
            Debug.Log("Level Complete");
            SceneManager.LoadScene(2);//load hub scene
        }
        if (other.gameObject.CompareTag("TpPad") && partFound == 1)//when the box collider is crossed and the part is found
        {
            Debug.Log("Level Complete");
            SceneManager.LoadScene(2);//load hub scene
        }
        if (other.gameObject.CompareTag("SearchArea"))//when the box collider is crossed and the part is found
        {
            Debug.Log("Part Close");
            Light1.SetActive(false);
            Light2.SetActive(true);
        }
        if (other.gameObject.CompareTag("ShipPart"))//when the collider is crossed and the part is found
        {
            Debug.Log("Part Found");
            other.gameObject.SetActive(false);
            partFound =  partFound + 1;
        }
    }
}
