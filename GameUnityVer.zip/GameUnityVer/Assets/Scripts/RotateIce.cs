﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RotateIce : MonoBehaviour {
    //used to rotate planets on the main menu/loading screens
    // Update is called once per frame
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();

        string sceneName = currentScene.name;
        if (sceneName == "Menu" || sceneName == "Extras" || sceneName == "Loading1" || sceneName == "Loading2")
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }
    void Update () {
        transform.Rotate(new Vector3(0f, 1f, 0f));
	}
}
