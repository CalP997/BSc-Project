// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "UnrealVer.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UnrealVer, "UnrealVer" );
