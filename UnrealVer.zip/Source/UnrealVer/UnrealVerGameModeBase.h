// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "UnrealVerGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class UNREALVER_API AUnrealVerGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
